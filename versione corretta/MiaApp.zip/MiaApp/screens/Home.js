import { StyleSheet, Text, View, Button } from 'react-native';
import { useNavigation } from '@react-navigation/native';

import { globalStyles } from '../style/globalStyle';
import usePosition from '../hooks/usePosition';

export default function Home() {

// costante per la geolocalizzazione
const { location, errorMessage } = usePosition();

  return (
    <View style={localStyles.container}>
      <View style={localStyles.row1}>
        <Text style={globalStyles.title}>Titolo</Text>
        <Text style={globalStyles.subTitle}>Sotto Titolo</Text>

      </View>
      <View style={localStyles.row2}>
        <View style={localStyles.column1}>
        
        {/* richiama il componente per chiedere il consenso per la geolocalizzazione */}
        { location?.coords && (
          <View style={localStyles.geoText}>
            <Text style={localStyles.geoTextColor}>Latitudine: {location.coords.latitude}</Text>
            <Text style={localStyles.geoTextColor}>Logitudine: {location.coords.longitude}</Text>
          </View>
        )}
        </View>
        <View style={localStyles.column2}>
        
        </View>
      </View>
      <View style={localStyles.row3}>
        
      </View>
    </View>
  );
}

const localStyles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ffffff',
  },
  row1: {
    flex: 1.7,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'lightyellow',
  },
  row2: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'center',
    backgroundColor: 'lightblue',
  },
  column1: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'lightblue',
  },
  column2: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'orange',
  },
  row3: {
    flex: 0.1,
    justifyContent: 'flex-end',
    alignContent: 'flex-end',
    backgroundColor: 'magenta',
  },
  geoTextColor: {
    color: 'blue',
  },
});
