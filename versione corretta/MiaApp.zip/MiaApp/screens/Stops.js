import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View } from 'react-native';
import { globalStyles } from '../style/globalStyle';
import Stop from '../components/Stop';

export default function App() {
  return (
    <View>
      <View>
        <Text style={globalStyles.title}>Stops</Text>
        <Stop />
      </View>
      <StatusBar style="auto" />
    </View>
  );
}