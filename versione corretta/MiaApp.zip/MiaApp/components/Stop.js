import React, { useState, useEffect } from "react";
import { View, Text, ScrollView, Pressable } from "react-native";
import { StyleSheet } from "react-native";
import usePosition from "../hooks/usePosition";
import { globalStyles } from "../style/globalStyle";

import { TRANSPORT_URL } from "../config/Config";
import { useNavigation } from "@react-navigation/native";


const Stop = () => {

    const [stopData, setStop] = useState([]);
    const { location, errorMessage } = usePosition();
    const navigation = useNavigation();

    useEffect(() => {
        
        const fetchData = async () => {
            const response = await fetch(`${TRANSPORT_URL}locations?x=${location.coords.latitude}&y=${location.coords.longitude}&type=all`);
            
            console.log('stop: ', stopData);
            const data = await response.json();
            //DEBUG
            console.log('Data: ', data);
            setStop(data);
            //DEBUG
            console.log("Location:", location);
        };
        
        if (location) {
            fetchData();
        }
    }, [location]);


    return (
    <>
        <View style={{flex:3, margin: 50}}>

        {stopData && (
            <ScrollView>
            {/* map serve per ciclare un array e visualizzare ogni elemento (come un foreach in PHP che salva chiave e valore in due variabili) */}
            {stopData.stations?.slice(1).map((object, index) => (
                // key serve per identificare ogni elemento strGlassdella lista e evitare errori di visualizzazione
                <View key={index} >

                    <Pressable onPress={() => navigation.push('StopDetail',{itemId: object.id})}>
                        <Text style={globalStyles.border}>
                            {object.name}
                        </Text>
                    </Pressable>
                </View>
            ))}
            </ScrollView>
        )}
        </View>
    </>
    )
}

const localStyles = StyleSheet.create({
    container: {
        textAlign: 'center',
    },
  });

export default Stop;
