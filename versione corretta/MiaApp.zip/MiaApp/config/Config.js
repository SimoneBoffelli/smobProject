export const TRANSPORT_URL = 'http://transport.opendata.ch/v1/';
export const TRANSPORT_URL_STATIONBOARD = 'http://transport.opendata.ch/v1/stationboard';