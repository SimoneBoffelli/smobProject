/*
Config.js
Autore: Simone e Sabri
Utilità: url statico da utilizzare negli altri componenti
*/
export const TRANSPORT_URL = 'http://transport.opendata.ch/v1/';