import { useEffect, useState } from "react";
import { View, Text, Pressable } from "react-native";
import { globalStyles } from "../style/globalStyle";
import { TRANSPORT_URL_STATIONBOARD } from "../config/Config";
import moment from "moment";
import { useNavigation } from '@react-navigation/native';

const StopDetail = ({ route }) => {
    const navigation = useNavigation();
    const goTo = () =>{
        navigation.push("Stop");
    }
    const [stopDetailData, setStopDetailData] = useState([])
    useEffect(() => {
        const fecthStopDetailData = async () => {
            const response = await fetch(`${TRANSPORT_URL_STATIONBOARD}?id=${route}&limit=50`)
            const data = await response.json()
            data.stationboard.map((data) => {
                data.stop.departure = moment(data.stop.departure).format('HH:mm')
            })
            setStopDetailData(data)
        }
        fecthStopDetailData()
    }, [])
    return (
        <View style={{flex:3, margin: 50}}>
            <Text style={globalStyles.detailTitle}>{stopDetailData.station?.name}</Text>
            <Pressable  style={globalStyles.back} onPress={goTo}><Text>Go back</Text></Pressable>
            {stopDetailData.stationboard?.map((stop, index) => (
                <View style={globalStyles.border} key={index}>
                    <Text style={globalStyles.subTitle}>Linea {stop.number}</Text>
                    <Text>Direzione {stop.to}</Text>
                    <Text>Partenza {stop.stop.departure}</Text>
                </View>
            ))}
        </View>
    );
}

export default StopDetail;