
import { Dimensions, ScrollView, View } from "react-native";
import StopDetail from "./StopDetail";


const RowStopDetail = ({ route }) => {
    const { itemId } = route.params;
    const screenHeight = Dimensions.get('window').height
    return (
        <View style={{ height: screenHeight }}>
            <ScrollView>
                    <StopDetail route={itemId}></StopDetail>
            </ScrollView>
        </View>
    );
}

export default RowStopDetail; 