import { StatusBar } from 'expo-status-bar';
import { useState } from 'react';
import axios from 'axios';
import { StyleSheet, View, Text, SafeAreaView, Image, TextInput, TouchableOpacity, TouchableWithoutFeedback } from 'react-native';
import { useNavigation } from '@react-navigation/native';

//in caso si errori sulla libreria btoa importare Base64
//import Base64 from 'Base64';


const Login = () => {

    const navigation = useNavigation();

    const API_URL = "https://webo.ssigno.ch/simoneboffelli/projects/webo_mvc_routing_request_2/restapi/login";

    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');

    const checkLogin = async () => {

        //soltanto se, sia username che password, contengo del testo
        if ((email !== '') && (password !== '')) {

            //creiamo i dati da inviare (il body) 
            const postData = {
                action: "login",  //parametro che indica al server l'operazione da svolgere
                username: email,
                password: password,
            };

            //codifichiamo il body in base64 cont btoa (Base64 encode) 
            
            const encodedData = btoa(JSON.stringify(postData));
			//in caso si errori sulla libreria btoa forzare l'utilizzo di Base64.btoa
			//const encodedData = Base64.btoa(JSON.stringify(postData));
            
            //inviamo la richiesta con in metodo POST
            const response = await axios.post(API_URL, encodedData,{
                              headers: {
                                'Content-Type': 'application/json'
                              	}
                            });

            //in base alla risposta del server modifichiamo il comportamento della nostra applicazione
            if (response.data.loginOk > 0) {
                //login ok
                console.log('loginOk !!');
                //set login variable, ...
                //navigazione verso un'altra pagina,...
                navigation.navigate('Home');
            } else {
                //login error
                console.log('login NOT OK!!');
            }
        }
    }

    return (
        <TouchableWithoutFeedback accessible={false}>
            <View style={styles.screen}>
                <StatusBar style="auto" />
                <SafeAreaView >
                    <View style={styles.row}>
                        <TextInput style={styles.input} inputMode="email" autoCapitalize='none' onChangeText={newText => setEmail(newText)} placeholder='e-mail'></TextInput>
                        <TextInput style={styles.input} secureTextEntry={true} autoCapitalize='none' onChangeText={newText => setPassword(newText)} placeholder='password'></TextInput>

                        <TouchableOpacity style={styles.button} onPress={checkLogin}>
                            <Text style={styles.buttonText} >Login</Text>
                        </TouchableOpacity>
                    </View>
                    <Image
                        source={require('../assets/icon.png')}
                        style={styles.img} />
                </SafeAreaView>
            </View>
        </TouchableWithoutFeedback>
    );
}

const styles = StyleSheet.create({
    screen: {
        flex: 1,
    },
    img: {
        padding: 50,
        marginTop: 20,
        alignItems: 'flex-end'
    },
    row: {
        backgroundColor: 'transparent',
        padding: 20,
        marginTop: 120,
    },
    button: {
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '#ccdf9c',
        paddingTop: 15,
        paddingBottom: 15,
        paddingRight: 25,
        paddingLeft: 25,
        margin: 10,
        borderRadius: 50,
        shadowRadius: 15,
        fontSize: 22,
        borderColor: 'lightgray',
        shadowColor: "#000000",
        shadowOffset: {
            width: 0,
            height: 2,
        },
        shadowOpacity: 0.2,
        shadowRadius: 2,
    },
    buttonText: {
        fontWeight: 'bold',
        fontSize: 22,
    },
    input: {
        paddingLeft: 10,
        borderWidth: 1,
        backgroundColor: 'transparent',
        paddingTop: 15,
        paddingBottom: 15,
        paddingRight: 25,
        paddingLeft: 25,
        margin: 10,
        borderRadius: 50,
        shadowRadius: 15,
        fontWeight: 'bold',
        fontSize: 22,
        borderColor: 'lightgray',
        shadowColor: "#000000",
        shadowOffset: {
            width: 0,
            height: 2,
        },
        shadowOpacity: 0.2,
        shadowRadius: 2,
    }
})

export default Login;