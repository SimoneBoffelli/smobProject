
import { NavigationContainer } from "@react-navigation/native";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import { createStackNavigator } from "@react-navigation/stack";
import { Ionicons } from "@expo/vector-icons";
import Stops from "./screens/Stops";
import RowStopDetail from "./components/RowStopDetail";
import Login from "./screens/Login";



const Tab = createBottomTabNavigator();
const Stack = createStackNavigator();

const App = () => {
  return (
    <NavigationContainer>
      <Stack.Navigator 
      initialRouteName="Stop"
      screenOptions={{ headerShown: false }}
      >
        <Stack.Screen 
          name="RowStopDetail" 
          component={RowStopDetail} />
          <Stack.Screen 
          name="Stop" 
          component={TabNavigator} />
          <Stack.Screen 
          name="Login" 
          component={Login} />
      </Stack.Navigator>
    </NavigationContainer>
  );
};
const TabNavigator = () => {
  return (
    <Tab.Navigator>
      <Tab.Screen
        name="Fermate"
        component={Stops}
        options={{
          headerShown: false,
          tabBarLabel: "Fermate",
          tabBarShowLabel: false,
          tabBarIcon: ({ color, size }) => (
            <Ionicons name="location" color={color} size={size} />
          ),
        }}
      />
      <Tab.Screen
        name="Login"
        component={Login}
        options={{
          headerShown: false,
          tabBarLabel: "Login",
          tabBarShowLabel: false,
          tabBarIcon: ({ color, size }) => (
            <Ionicons name="log-in" color={color} size={size} />
          ),
        }}
      />
    </Tab.Navigator>
  )
}



export default App;
