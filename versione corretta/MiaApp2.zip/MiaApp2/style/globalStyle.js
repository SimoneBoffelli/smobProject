/* Questo file serve come file di stile globale per tutto il progetto  
(tipo un file style.css)*/

// importa il modulo StyleSheet da react-native
import { StyleSheet } from "react-native"; 

const globalStyles = StyleSheet.create({
    container: {
        flex: 1,
        textAlign: 'center',
        alignItems: 'center',
        justifyContent: 'center',
        margin: 10,
    },
    title: {
        flex: 1,
        textAlign: 'center',
        alignItems: 'center',
        justifyContent: 'center',
        fontSize: 30,
        fontWeight: 'bold',
        marginBottom: -50,
        marginTop: 50,
    },
    detailTitle: {
        flex: 1,
        textAlign: 'center',
        alignItems: 'center',
        justifyContent: 'center',
        fontSize: 30,
        fontWeight: 'bold',
        marginBottom: 25,
        marginTop: 50,
    },
    subTitle: {
        fontSize: 15,
        fontWeight: 'bold',
    },
    border: {
        padding: 5,
        border: 'solid',
        borderWidth: 1,
        borderRadius: 5,
        borderColor: 'gray',
        marginBottom: 10,
        /* Non funziona 
        elevation: 5,*/
        /* Elementi per ombra */
        shadowOffset: {width: -2, height: 4},  
        shadowColor: '#171717', 
        shadowOpacity: 0.2,  
        shadowRadius: 3,
    },
    back: {
        flex: 1,
        textAlign: 'center',
        alignItems: 'center',
        justifyContent: 'center',
        fontSize: 20,
        border: 'solid',
        borderWidth: 1,
        borderRadius: 5,
        borderColor: 'gray',
        marginBottom: 10,
        shadowOffset: {width: -2, height: 4},  
        shadowColor: '#171717', 
        shadowOpacity: 0.2,  
        shadowRadius: 3,
        maxHeight: 50,
        width: 200,
        
    },
});

export {globalStyles}; 
