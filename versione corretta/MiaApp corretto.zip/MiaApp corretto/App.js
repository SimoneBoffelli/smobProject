
import { NavigationContainer } from "@react-navigation/native";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import { createStackNavigator } from "@react-navigation/stack";
import { Ionicons } from "@expo/vector-icons";

import StopDetail from "./components/StopDetail";
import Login from "./screens/Login";

import Stops from "./screens/Stops";

const Tab = createBottomTabNavigator();
const Stack = createStackNavigator();

const App = () => {
  return (
    <NavigationContainer>
      <Stack.Navigator 
      initialRouteName="Stop"
      screenOptions={{ headerShown: false }}
      >
        <Stack.Screen 
            name="Login" 
            component={Login} />
        <Stack.Screen 
          name="StopDetail" 
          component={StopDetail} />
          <Stack.Screen 
          name="Stop" 
          component={TabNavigator} />
      </Stack.Navigator>
    </NavigationContainer>
  );
};

const TabNavigator = () => {
  return (
    <Tab.Navigator
    style={{
      tabBarPosition: "bottom",
      tabBarTopOffset: 20,
    }}
  >
    <Tab.Screen
      name="Home"
      component={Stops}
      screenOptions={{ headerShown: false }}
      options={{
        tabBarLabel: "Fermate",
        tabBarShowLabel: false,
        tabBarIcon: ({ color, size }) => (
          <Ionicons name="home" color={color} size={size} />
        ),
      }}
    />
    <Tab.Screen
      name="Login"
      component={Login}
      options={{
        tabBarLabel: "Login",
        tabBarShowLabel: false,
        tabBarIcon: ({ color, size }) => (
          <Ionicons name="log-in" color={color} size={size} />
        ),
      }}
    />
  </Tab.Navigator>
  )};


export default App;
