import React, { useEffect, useState } from "react";
import { View, Text, ScrollView } from "react-native";
import { globalStyles } from "../style/globalStyle";
import { TRANSPORT_URL_STATIONBOARD } from "../config/Config";
import moment from "moment";


const StopDetail = ({ route }) => {
    // versione consegnata (sbagliata)
    //const itemId = route.itemId;
    const { itemId } = route.params;
    console.log(itemId)
    const [stopDetailData, setStopDetailData] = useState([])
    useEffect(() => {
        const fecthStopDetailData = async () => {
            const response = await fetch(`${TRANSPORT_URL_STATIONBOARD}?id=${itemId}&limit=20`)
            const data = await response.json()
            data.stationboard.map((data)=>{
                data.stop.departure = moment(data.stop.departure).format('HH:mm')
            })
            setStopDetailData(data)
            console.log(data)
            console.log(data.station.name)
        }
        fecthStopDetailData()
    }, [])   
    
    return (

        <View style={{flex:3, margin: 50}}>
            {stopDetailData && (
                <>
                    <Text style={globalStyles.title}>{stopDetailData.station?.name}</Text>
                    <ScrollView style={{height: 200}}>
                        {stopDetailData.stationboard?.map((stop, index) => (
                            <View style={globalStyles.border} key={index}>
                                <Text style={globalStyles.subTitle}>Linea {stop.number}</Text>
                                <Text>Direzione {stop.to}</Text>
                                <Text>Partenza {stop.stop.departure}</Text>
                            </View>
                        ))}
                    </ScrollView>
                </>
            )}
        </View>
        
    );
};

export default StopDetail;