
import StopDetail from "../components/StopDetail";


const RowStopDetail = () =>{
    return(
        <StopDetail></StopDetail>
    );
}

export default RowStopDetail; 