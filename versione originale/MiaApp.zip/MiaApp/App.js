
import { NavigationContainer } from "@react-navigation/native";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import { createStackNavigator } from "@react-navigation/stack";

import { Ionicons } from "@expo/vector-icons";
import StopDetail from "./components/StopDetail";

import Stops from "./screens/Stops";

const Tab = createBottomTabNavigator();
const Stack = createStackNavigator();

const App = () => {
  return (
    <NavigationContainer>
      <Stack.Navigator 
      initialRouteName="Stop"
      screenOptions={{ headerShown: false }}
      >
        <Stack.Screen 
          name="StopDetail" 
          component={StopDetail} />
          <Stack.Screen 
          name="Stop" 
          component={Stops} />
      </Stack.Navigator>
    </NavigationContainer>
  );
};



export default App;
