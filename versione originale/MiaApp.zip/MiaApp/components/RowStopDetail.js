
import { ScrollView } from "react-native-web";
import StopDetail from "./StopDetail";


const RowStopDetail = () =>{
    return(
        <ScrollView>
            <StopDetail></StopDetail>
        </ScrollView>
    );
}

export default RowStopDetail; 