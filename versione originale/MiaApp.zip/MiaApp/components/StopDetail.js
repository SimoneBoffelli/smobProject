import { useEffect, useState } from "react";
import { View, Text } from "react-native";
import { globalStyles } from "../style/globalStyle";
import { TRANSPORT_URL_STATIONBOARD } from "../config/Config";
import moment from "moment";


const StopDetail = ({ route }) => {
    // versione consegnata (sbagliata)
    const itemId = route.itemId;
    //const { itemId } = route.params;
    console.log(itemId)
    const [stopDetailData, setStopDetailData] = useState([])
    useEffect(() => {
        const fecthStopDetailData = async () => {
            const response = await fetch(`${TRANSPORT_URL_STATIONBOARD}?id=${itemId}&limit=20`)
            const data = await response.json()
            data.stationboard.map((data)=>{
                data.stop.departure = moment(data.stop.departure).format('HH:mm:ss')
            })
            setStopDetailData(data)
            console.log(data)
            console.log(data.station.name)
        }
        fecthStopDetailData()
    }, [])   
    return(
        <View>
            <Text style={globalStyles.title}>{stopDetailData.station?.name}</Text>
            {stopDetailData.stationboard?.map((stop, index)=>(
                <View  style={globalStyles.border} key={index}>
                    <Text  style={globalStyles.subTitle}>Linea {stop.number}</Text>
                    <Text>Direzione {stop.to}</Text>
                    <Text>Partenza {stop.departure}</Text> 
                </View>
            ))}
        </View>
    );
}

export default StopDetail;