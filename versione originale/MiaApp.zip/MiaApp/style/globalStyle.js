/* Questo file serve come file di stile globale per tutto il progetto  
(tipo un file style.css)*/

// importa il modulo StyleSheet da react-native
import { StyleSheet } from "react-native"; 

const globalStyles = StyleSheet.create({
    container: {
        flex: 1,
        textAlign: 'center',
        alignItems: 'center',
        justifyContent: 'center',
        margin: 10,
    },
    title: {
        fontSize: 30,
        fontWeight: 'bold',
    },
    subTitle: {
        fontSize: 15,
        fontWeight: 'bold',
    },
    border: {
        padding: 5,
        border: 'solid',
        borderWidth: 1,
        borderRadius: 5,
        borderColor: 'gray',
        elevation: 5,
    },

});

export {globalStyles}; 
